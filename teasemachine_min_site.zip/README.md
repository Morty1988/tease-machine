Minimal Next.js app for TeaseMachine.ai
- Home at app/page.js
- Demo API at app/api/handy/route.js

Deploy with Vercel:
1) Upload these files to your project (Add files via upload), or push to GitHub and import.
2) Vercel will auto-detect Next.js and build.
