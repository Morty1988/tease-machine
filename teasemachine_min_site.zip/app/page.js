'use client';
import { useState } from 'react';

export default function Home() {
  const [log, setLog] = useState('Waiting…');

  async function ping(action) {
    const res = await fetch('/api/handy', { method: 'POST', body: JSON.stringify({ action }) });
    const text = await res.text();
    setLog(text);
  }

  return (
    <main>
      <h1 style={{ marginTop:0 }}>Mistress Susi — TeaseMachine.ai</h1>
      <p>Minimal working site. Buttons call <code>/api/handy</code> (demo mode by default).</p>
      <div style={{ display:'flex', gap:10, margin:'16px 0' }}>
        <button onClick={()=>ping('edge')}>Edge me</button>
        <button onClick={()=>ping('deny')}>Deny me</button>
        <button onClick={()=>ping('let-me-come')}>Let me come</button>
      </div>
      <pre style={{ background:'#12121a', padding:12, borderRadius:8 }}>{log}</pre>
    </main>
  );
}
