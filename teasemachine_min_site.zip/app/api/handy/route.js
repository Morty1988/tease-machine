import { NextResponse } from 'next/server';

export async function POST(req) {
  const bodyText = await req.text();
  return new NextResponse(JSON.stringify({ ok:true, demo:true, received: bodyText || null }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
