export const metadata = { title: 'TeaseMachine.ai' };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin:0, fontFamily:'system-ui, sans-serif', background:'#0b0b10', color:'#eee' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 20px' }}>{children}</div>
      </body>
    </html>
  );
}
